import subprocess
import sys
from pathlib import Path
from pdf2image import convert_from_path
from music21 import converter, midi
import tkinter as tk
from tkinter import filedialog

# --- ÉTAPE 0 : CHOISIR LE FICHIER ---
def choisir_fichier():
    root = tk.Tk()
    root.withdraw()
    return filedialog.askopenfilename(
        title="Choisir une partition",
        filetypes=[("Images & PDF", "*.pdf *.png *.jpg *.jpeg")]
    )

# --- ÉTAPE 1 : OMR avec oemer ---
def image_vers_musicxml(chemin_entree: str) -> Path:
    chemin = Path(chemin_entree)
    dossier_sortie = chemin.parent / "output_oemer"
    dossier_sortie.mkdir(exist_ok=True)

    # Convertir PDF en PNG si nécessaire
    if chemin.suffix.lower() == ".pdf":
        print("📄 Conversion PDF → PNG...")
        pages = convert_from_path(str(chemin), dpi=300)
        chemin_img = chemin.parent / (chemin.stem + "_page1.png")
        pages[0].save(str(chemin_img), "PNG")
        print(f"   Image sauvegardée : {chemin_img.name}")
    else:
        chemin_img = chemin

    print(f"🎵 Analyse OMR en cours : {chemin_img.name} ...")
    subprocess.run(
        ["oemer", str(chemin_img), "-o", str(dossier_sortie)],
        check=True
    )

    resultats = list(dossier_sortie.glob("*.musicxml"))
    if not resultats:
        raise FileNotFoundError("oemer n'a pas généré de MusicXML. Vérifie la partition.")

    return resultats[0]

# --- ÉTAPE 2 : MusicXML → MIDI via music21 ---
def musicxml_vers_midi(chemin_xml: Path) -> Path:
    print(f"📄 Lecture du MusicXML : {chemin_xml.name}")
    partition = converter.parse(str(chemin_xml))

    # Affichage des notes dans le terminal
    print("\n--- NOTES DÉTECTÉES ---")
    for element in partition.flat.notes:
        if hasattr(element, 'pitch'):
            print(f"  {element.pitch.nameWithOctave:<6}  durée: {element.duration.type}")
        else:
            noms = [p.nameWithOctave for p in element.pitches]
            print(f"  [{', '.join(noms)}]  durée: {element.duration.type}")

    # Export MIDI
    chemin_midi = chemin_xml.with_suffix(".mid")
    mf = midi.translate.music21ObjectToMidiFile(partition)
    mf.open(str(chemin_midi), 'wb')
    mf.write()
    mf.close()
    print(f"\n✅ MIDI exporté : {chemin_midi}")
    return chemin_midi

# --- ÉTAPE 3 : Lecture audio avec FluidSynth ---
def jouer_midi(chemin_midi: Path):
    # Chemins possibles selon la distro Linux
    chemins_soundfont = [
        "/usr/share/sounds/sf2/FluidR3_GM.sf2",
        "/usr/share/soundfonts/FluidR3_GM.sf2",
        "/usr/share/sounds/sf2/TimGM6mb.sf2",
    ]

    soundfont = None
    for chemin in chemins_soundfont:
        if Path(chemin).exists():
            soundfont = chemin
            break

    if soundfont is None:
        print("⚠️  Aucune soundfont trouvée. Installe-en une :")
        print("   sudo apt install fluid-soundfont-gm")
        print(f"   Le fichier MIDI est disponible ici : {chemin_midi}")
        return

    print(f"🔊 Lecture en cours avec : {soundfont}")
    subprocess.run([
        "fluidsynth",
        "-a", "alsa",   # remplace par "coreaudio" sur macOS
        "-ni",
        soundfont,
        str(chemin_midi)
    ])

# --- EXÉCUTION ---
if __name__ == "__main__":
    fichier = choisir_fichier()
    if not fichier:
        print("Aucun fichier sélectionné.")
        sys.exit(0)

    try:
        chemin_xml = image_vers_musicxml(fichier)
        chemin_midi = musicxml_vers_midi(chemin_xml)
        jouer_midi(chemin_midi)
    except subprocess.CalledProcessError as e:
        print(f"❌ Erreur lors de l'analyse oemer : {e}")
        print("   Vérifie que oemer est bien installé : pip install oemer")
    except FileNotFoundError as e:
        print(f"❌ Fichier introuvable : {e}")
    except Exception as e:
        print(f"❌ Erreur inattendue : {e}")